"""
Text branch of the injury pipeline (extraction only).

Flowchart:  text -> keywords -> location / pain / other description
"""
import re
import spacy
import pandas as pd

nlp = spacy.load("en_core_web_sm")
ruler = nlp.add_pipe("entity_ruler", before="ner")


# keywords
# each key is the normalised id, each value lists the ways a user might type it.
# one pattern per spelling, all sharing an id, so knees and knee both give knee.
BODY_PARTS = {
    "knee": ["knee", "knees"], "ankle": ["ankle", "ankles"],
    "shoulder": ["shoulder", "shoulders"], "hip": ["hip", "hips"],
    "hamstring": ["hamstring", "hamstrings", "hammy"], "calf": ["calf", "calves"],
    "quadriceps": ["quad", "quads", "quadriceps"], "wrist": ["wrist", "wrists"],
    "elbow": ["elbow", "elbows"], "groin": ["groin"], "shin": ["shin", "shins"],
    "foot": ["foot", "feet"], "neck": ["neck"],
}
SYMPTOMS = {
    "pain": ["pain", "painful", "sore", "soreness", "ache", "aches", "hurts", "hurt", "hurting"],
    "swelling": ["swelling", "swollen", "puffy"],
    "bruising": ["bruising", "bruised", "bruise"],
    "stiffness": ["stiffness", "stiff", "tight", "tightness"],
    "popping": ["popping", "popped", "clicking", "clicks"],
    "numbness": ["numbness", "numb"],
    "tingling": ["tingling", "tingly"],
}
PAIN_TYPES = {
    "sharp": ["sharp", "stabbing", "shooting"], "dull": ["dull", "aching", "achy"],
    "throbbing": ["throbbing", "pulsing"], "severe": ["severe", "unbearable", "intense"],
    "mild": ["mild", "slight"], "burning": ["burning"],
}
INJURIES = {
    "sprain": ["sprain", "sprained"], "strain": ["strain", "strained", "pulled"],
    "tear": ["tear", "torn"], "fracture": ["fracture", "fractured", "broken", "broke"],
    "dislocation": ["dislocated", "dislocation"],
    "acl": ["acl"],  # a ligament, so it lives here rather than under body_part
}
MOVEMENTS = {
    "jump": ["jump", "jumps", "jumping", "jumped", "landing", "landed"],
    "lunge": ["lunge", "lunges", "lunging"], "squat": ["squat", "squats", "squatting"],
    "run": ["run", "running", "sprint", "sprinting"], "twist": ["twist", "twisted", "rolled"],
}
SPORTS = ["athletics", "badminton", "basketball", "cricket", "football",
          "hockey", "swimming", "tennis", "rugby", "netball"]
TIME_UNITS = ["hour", "hours", "day", "days", "week", "weeks", "month", "months"]


def build_patterns():
    patterns = []
    for label, table in [("body_part", BODY_PARTS), ("symptom", SYMPTOMS),
                         ("pain_type", PAIN_TYPES), ("injury", INJURIES),
                         ("movement", MOVEMENTS)]:
        for norm, forms in table.items():
            for form in forms:
                patterns.append({"label": label, "pattern": [{"LOWER": form}], "id": norm})
    for sport in SPORTS:
        patterns.append({"label": "sport", "pattern": [{"LOWER": sport}], "id": sport})

    patterns += [
        {"label": "body_part", "pattern": [{"LOWER": "lower"}, {"LOWER": "back"}], "id": "lower back"},
        {"label": "side", "pattern": [{"LOWER": {"IN": ["left", "right", "both"]}}]},

        # Multi-word mobility symptoms. A single-word "limited" pattern would also
        # fire on "limited time", "limited space" and so on, so it is left out.
        {"label": "symptom", "pattern": [{"LOWER": {"IN": ["limited", "reduced"]}},
                                         {"LOWER": "mobility"}], "id": "limited_mobility"},
        {"label": "symptom", "pattern": [{"LOWER": {"IN": ["limited", "reduced"]}},
                                         {"LOWER": "range"}, {"LOWER": "of"},
                                         {"LOWER": {"IN": ["motion", "movement"]}}],
         "id": "limited_mobility"},

        # Duration: "3 days", "two weeks", "a week", "a few days"
        {"label": "duration", "pattern": [{"LIKE_NUM": True}, {"LOWER": {"IN": TIME_UNITS}}]},
        {"label": "duration", "pattern": [{"LOWER": {"IN": ["a", "an"]}}, {"LOWER": {"IN": TIME_UNITS}}]},
        {"label": "duration", "pattern": [{"LOWER": "a"}, {"LOWER": {"IN": ["few", "couple"]}},
                                          {"LOWER": "of", "OP": "?"}, {"LOWER": {"IN": TIME_UNITS}}]},

        # Pain score: "7/10"
        {"label": "pain_score", "pattern": [{"TEXT": {"REGEX": r"^\d{1,2}/10$"}}]},
        {"label": "pain_score", "pattern": [{"IS_DIGIT": True}, {"TEXT": "/"}, {"TEXT": "10"}]},
        {"label": "pain_score", "pattern": [{"IS_DIGIT": True}, {"LOWER": "out"},
                                            {"LOWER": "of"}, {"TEXT": "10"}]},
    ]
    return patterns