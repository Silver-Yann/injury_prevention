# injury prevention group25

[image info](photos/image.png)

predictive model which allows users to upload photos of pain areas, and describe which will eventually give a guesstimation on recovery time and exercises (?) to help with recovery