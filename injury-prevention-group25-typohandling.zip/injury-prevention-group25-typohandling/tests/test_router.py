
"""Tests for the T3-04 Basic Data Router."""

import json
import unittest

from app.routing.router import route_data


VISION = {
    "body_part": "knee",
    "side": "left",
    "injury_type": "knee_injury",
    "confidence": 0.82
}

NLP = {
    "body_part": "knee",
    "side": "left",
    "pain_score": 7,
    "symptoms": ["swelling", "pain"],
    "duration_days": 3,
    "confidence": 0.76
}

TRAINING = {
    "training_hours": 12.5,
    "training_intensity": 8,
    "sleep_hours": 6.5,
    "fatigue_level": 7,
    "recovery_index": 55
}


class RouterTests(unittest.TestCase):

    def test_all_sources(self):
        result = route_data(VISION, NLP, TRAINING)

        self.assertEqual(result["body_part"], "knee")
        self.assertEqual(result["side"], "left")
        self.assertEqual(result["vision"], {
            "injury_type": "knee_injury",
            "confidence": 0.82
        })
        self.assertEqual(result["nlp"]["symptoms"], ["swelling", "pain"])
        self.assertEqual(result["training"]["training_hours"], 12.5)

    def test_missing_vision(self):
        result = route_data(nlp_result=NLP, training_data=TRAINING)

        self.assertIsNone(result["vision"])
        self.assertEqual(result["body_part"], "knee")
        self.assertEqual(result["side"], "left")

    def test_missing_nlp(self):
        result = route_data(vision_result=VISION, training_data=TRAINING)

        self.assertIsNone(result["nlp"])
        self.assertEqual(result["vision"]["injury_type"], "knee_injury")

    def test_missing_training(self):
        result = route_data(vision_result=VISION, nlp_result=NLP)

        self.assertIsNone(result["training"])

    def test_all_missing(self):
        result = route_data()

        self.assertEqual(result, {
            "body_part": None,
            "side": None,
            "vision": None,
            "nlp": None,
            "training": None
        })

    def test_invalid_source_type(self):
        result = route_data(
            vision_result="not a dictionary",
            nlp_result=NLP
        )

        self.assertIsNone(result["vision"])
        self.assertEqual(result["body_part"], "knee")

    def test_invalid_fields(self):
        result = route_data(
            vision_result={
                "body_part": "",
                "confidence": 2
            },
            nlp_result={
                "body_part": "ankle",
                "pain_score": "seven",
                "symptoms": ["pain", 3]
            },
            training_data={
                "training_hours": -4,
                "sleep_hours": 6
            }
        )

        self.assertEqual(result["body_part"], "ankle")
        self.assertIsNone(result["vision"]["confidence"])
        self.assertIsNone(result["nlp"]["pain_score"])
        self.assertIsNone(result["nlp"]["symptoms"])
        self.assertIsNone(result["training"]["training_hours"])
        self.assertEqual(result["training"]["sleep_hours"], 6)

        self.assertEqual(set(result["training"]), {
            "training_hours",
            "training_intensity",
            "sleep_hours",
            "fatigue_level",
            "recovery_index"
        })

    def test_conflicting_sources(self):
        result = route_data(
            vision_result={
                "body_part": "knee",
                "side": "left"
            },
            nlp_result={
                "body_part": "ankle",
                "side": "right"
            }
        )

        self.assertEqual(result["body_part"], "knee")
        self.assertEqual(result["side"], "left")

    def test_json_output(self):
        result = route_data(
            vision_result={"confidence": float("nan")},
            training_data={"training_hours": float("inf")}
        )

        encoded = json.dumps(result, allow_nan=False)

        self.assertIsInstance(json.loads(encoded), dict)
        self.assertIsNone(result["vision"]["confidence"])
        self.assertIsNone(result["training"]["training_hours"])


if __name__ == "__main__":
    unittest.main()
