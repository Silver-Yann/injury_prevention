# Data Dictionary

This document describes the main fields used in the datasets for the injury prevention and recovery project.

The datasets are used for different purposes:

- **Training/Recovery dataset**: general training and recovery information
- **Biomechanical dataset**: movement and biomechanical measurements
- **Collegiate Injury dataset**: athlete workload, ACL risk and injury occurrence

## Field Roles

- **Identifier**: identifies an athlete or subject
- **Input**: information that may be used by the prediction model
- **Target**: value that the model may try to predict
- **Metadata**: useful information for tracking or history

---

# 1. Athlete Training and Recovery Dataset

| Field | Type | Meaning | Role |
|---|---|---|---|
| Athlete_ID | string | Unique athlete identifier | Identifier |
| Sport_Type | string | Type of sport performed by the athlete | Input |
| Training_Hours | float | Number of training hours | Input |
| Training_Intensity | integer | Training intensity score | Input |
| Sleep_Hours | float | Number of hours the athlete sleeps | Input |
| Nutrition_Score | integer | Score representing nutrition quality | Input |
| Fatigue_Level | integer | Athlete fatigue level | Input |
| Recovery_Index | integer | Score representing recovery level | Input |
| Performance_Score | integer | Athlete performance score | Input |
| Injury_Risk | string | Injury risk category: Low, Medium or High | Target |
| Date | string/date | Date of the training/recovery record | Metadata |

## Main purpose

This dataset can be used to estimate general injury risk based on training and recovery information.

### Possible model inputs

- Sport_Type
- Training_Hours
- Training_Intensity
- Sleep_Hours
- Nutrition_Score
- Fatigue_Level
- Recovery_Index
- Performance_Score

### Possible prediction target

- Injury_Risk

---

# 2. Biomechanical Injury Prevention Dataset

| Field | Type | Meaning | Role |
|---|---|---|---|
| Subject ID | string | Unique subject identifier | Identifier |
| Age | integer | Age of the athlete | Input |
| Gender | string | Gender of the athlete | Input |
| Height (cm) | integer | Height of the athlete in centimetres | Input |
| Weight (kg) | integer | Weight of the athlete in kilograms | Input |
| Fitness Level | string | Athlete fitness level | Input |
| Movement Type | string | Type of movement being performed | Input |
| Time (sec) | float | Duration of the movement | Input |
| Knee Angle (deg) | float | Knee joint angle in degrees | Input |
| Hip Angle (deg) | float | Hip joint angle in degrees | Input |
| Ankle Angle (deg) | float | Ankle joint angle in degrees | Input |
| Velocity (m/s) | float | Movement velocity | Input |
| Acceleration (m/s²) | float | Movement acceleration | Input |
| Knee Load (N) | float | Force/load measured on the knee | Input |
| Hip Load (N) | float | Force/load measured on the hip | Input |
| Ankle Load (N) | float | Force/load measured on the ankle | Input |
| Quad EMG (mV) | float | Quadriceps muscle activity measured using EMG | Input |
| Hamstring EMG (mV) | float | Hamstring muscle activity measured using EMG | Input |
| Calf EMG (mV) | float | Calf muscle activity measured using EMG | Input |
| Irregularities Detected | string | Indicates whether irregular movement was detected | Input |
| Movement Symmetry | float | Measurement of movement symmetry | Input |
| Injury Risk Factor | string | Injury risk category | Target |
| Injury Type | string | Type of injury associated with the movement | Target |

## Main purpose

This dataset can be used to analyse movement and biomechanical measurements and identify possible injury risk or injury type.

### Possible model inputs

- Age
- Gender
- Height
- Weight
- Fitness Level
- Movement Type
- Time
- Knee Angle
- Hip Angle
- Ankle Angle
- Velocity
- Acceleration
- Knee Load
- Hip Load
- Ankle Load
- Quad EMG
- Hamstring EMG
- Calf EMG
- Irregularities Detected
- Movement Symmetry

### Possible prediction targets

- Injury Risk Factor
- Injury Type

---

# 3. Collegiate Athlete Injury Dataset

| Field | Type | Meaning | Role |
|---|---|---|---|
| Athlete_ID | string | Unique athlete identifier | Identifier |
| Age | integer | Age of the athlete | Input |
| Gender | string | Gender of the athlete | Input |
| Height_cm | integer | Height of the athlete in centimetres | Input |
| Weight_kg | integer | Weight of the athlete in kilograms | Input |
| Position | string | Athlete playing position | Input |
| Training_Intensity | integer | Athlete training intensity | Input |
| Training_Hours_Per_Week | integer | Number of training hours per week | Input |
| Recovery_Days_Per_Week | integer | Number of recovery days per week | Input |
| Match_Count_Per_Week | integer | Number of matches or events per week | Input |
| Rest_Between_Events_Days | integer | Number of rest days between events | Input |
| Fatigue_Score | integer | Athlete fatigue score | Input |
| Performance_Score | integer | Athlete performance score | Input |
| Team_Contribution_Score | integer | Score representing contribution to the team | Input |
| Load_Balance_Score | integer | Score representing workload balance | Input |
| ACL_Risk_Score | integer | Score representing ACL injury risk | Target |
| Injury_Indicator | integer | Indicates whether an injury occurred: 0 = no injury, 1 = injury | Target |

## Main purpose

This dataset can be used to analyse the relationship between workload, fatigue, recovery and injury occurrence.

### Possible model inputs

- Age
- Gender
- Height_cm
- Weight_kg
- Position
- Training_Intensity
- Training_Hours_Per_Week
- Recovery_Days_Per_Week
- Match_Count_Per_Week
- Rest_Between_Events_Days
- Fatigue_Score
- Performance_Score
- Team_Contribution_Score
- Load_Balance_Score

### Possible prediction targets

- ACL_Risk_Score
- Injury_Indicator

---

# 4. Golden Dataset

The `golden_dataset.csv` combines the three source datasets into one file.

It contains the following source categories:

- athlete_training_recovery
- biomechanical_injury_prevention
- collegiate_athlete_injury

The datasets do not contain the same fields, so many values in the golden dataset are empty depending on the source dataset.

This is expected when different source datasets are stacked together.

## Important current issue

The current golden dataset contains mapping problems:

### Athlete Training and Recovery

`injury_type` currently contains the same values as `injury_risk`.

Example:

- Low
- Medium
- High

This is incorrect because the original Athlete Training and Recovery dataset does not contain an Injury Type field.

### Biomechanical Dataset

The original dataset contains:

- Injury Risk Factor
- Injury Type

However, the current golden dataset has no values in:

`injury_risk_factor`

This indicates that the target-column mapping needs to be corrected before the golden dataset is used for model training.

---

# 5. Dataset Relationship

The datasets should not currently be joined athlete-by-athlete.

The athlete identifiers are different between datasets and do not represent the same people.

Therefore, the datasets should be treated as separate data sources.

They may later be combined at the application level through the T3 routing system rather than being directly merged row by row.

---

# 6. Current Target Variables

The project currently has several different target variables:

| Target | Dataset | Purpose |
|---|---|---|
| Injury_Risk | Training/Recovery | General injury risk |
| Injury Risk Factor | Biomechanical | Biomechanical injury risk |
| Injury Type | Biomechanical | Type of injury |
| ACL_Risk_Score | Collegiate Injury | ACL risk score |
| Injury_Indicator | Collegiate Injury | Whether an injury occurred |

These targets should remain separate because they represent different predictions.