"""T3-04: Validate and combine T1, T2 and training data."""

import json
import math


def _text(value):
    """Return a nonempty string, or None."""
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _number(value):
    """Accept finite, nonnegative numbers."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None

    if not math.isfinite(value) or value < 0:
        return None

    return value


def _confidence(value):
    """Confidence must be between 0 and 1."""
    number = _number(value)

    if number is not None and number <= 1:
        return number

    return None


def _days(value):
    """Duration must be a nonnegative integer."""
    if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
        return value

    return None


def _symptoms(value):
    """Validate a list of symptoms."""
    if not isinstance(value, list):
        return None

    cleaned = [_text(item) for item in value]

    if any(item is None for item in cleaned):
        return None

    return cleaned


def _normalize(source, fields):
    """Validate the fields of an input dictionary."""
    if not isinstance(source, dict):
        return None

    return {
        name: validator(source.get(name))
        for name, validator in fields.items()
    }


def route_data(vision_result=None, nlp_result=None, training_data=None):
    """Validate and combine all available input sources."""

    # T1: Computer Vision
    vision = _normalize(vision_result, {
        "injury_type": _text,
        "confidence": _confidence
    })

    # T2: Natural Language Processing
    nlp = _normalize(nlp_result, {
        "pain_score": _number,
        "symptoms": _symptoms,
        "duration_days": _days,
        "confidence": _confidence
    })

    # T3: Athlete and Training Data
    training = _normalize(training_data, {
        "training_hours": _number,
        "training_intensity": _number,
        "sleep_hours": _number,
        "fatigue_level": _number,
        "recovery_index": _number
    })

    # Extract body part and side from T1
    vision_body = (
        _text(vision_result.get("body_part"))
        if isinstance(vision_result, dict) else None
    )

    vision_side = (
        _text(vision_result.get("side"))
        if isinstance(vision_result, dict) else None
    )

    # Extract body part and side from T2
    nlp_body = (
        _text(nlp_result.get("body_part"))
        if isinstance(nlp_result, dict) else None
    )

    nlp_side = (
        _text(nlp_result.get("side"))
        if isinstance(nlp_result, dict) else None
    )

    # Prefer T1 values, otherwise use T2
    body_part = vision_body if vision_body is not None else nlp_body
    side = vision_side if vision_side is not None else nlp_side

    # Create consistent output
    result = {
        "body_part": body_part,
        "side": side,
        "vision": vision,
        "nlp": nlp,
        "training": training
    }

    return result


if __name__ == "__main__":

    # Example T1 input
    test_vision = {
        "body_part": "knee",
        "side": "left",
        "injury_type": "knee_injury",
        "confidence": 0.82
    }

    # Example T2 input
    test_nlp = {
        "body_part": "knee",
        "side": "left",
        "pain_score": 7,
        "symptoms": ["swelling", "pain"],
        "duration_days": 3,
        "confidence": 0.76
    }

    # Example training input
    test_training = {
        "training_hours": 12.5,
        "training_intensity": 8,
        "sleep_hours": 6.5,
        "fatigue_level": 7,
        "recovery_index": 55
    }

    # Combine the data
    combined = route_data(test_vision, test_nlp, test_training)

    # Print the result as JSON
    print(json.dumps(combined, indent=2, allow_nan=False))
