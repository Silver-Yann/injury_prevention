from app.database.database import SessionLocal
from app.database.models import Athlete, TrainingRecord, Assessment


def test_database():
    db = SessionLocal()

    try:
        # Create athlete
        athlete = Athlete(
            age=22,
            gender="male",
            height_cm=180,
            weight_kg=78
        )

        db.add(athlete)
        db.commit()
        db.refresh(athlete)

        print(f"Athlete created with ID: {athlete.id}")

        # Create training record
        training = TrainingRecord(
            athlete_id=athlete.id,
            training_hours=12.5,
            training_intensity=8,
            sleep_hours=6.5,
            fatigue_level=7,
            recovery_index=55,
            performance_score=72
        )

        db.add(training)

        # Create assessment
        assessment = Assessment(
            athlete_id=athlete.id,
            predicted_injury="knee_injury",
            risk_level="high",
            confidence=0.82
        )

        db.add(assessment)

        db.commit()

        # Read athlete back
        saved_athlete = db.query(Athlete).filter(
            Athlete.id == athlete.id
        ).first()

        print("\nSaved athlete:")
        print(f"ID: {saved_athlete.id}")
        print(f"Age: {saved_athlete.age}")
        print(f"Gender: {saved_athlete.gender}")

        print("\nTraining records:")
        for record in saved_athlete.training_records:
            print(
                f"Training hours: {record.training_hours}, "
                f"Intensity: {record.training_intensity}"
            )

        print("\nAssessments:")
        for result in saved_athlete.assessments:
            print(
                f"Injury: {result.predicted_injury}, "
                f"Risk: {result.risk_level}, "
                f"Confidence: {result.confidence}"
            )

    finally:
        db.close()


if __name__ == "__main__":
    test_database()