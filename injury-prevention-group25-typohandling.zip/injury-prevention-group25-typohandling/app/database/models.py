from sqlalchemy import Column, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.database.database import Base


class Athlete(Base):
    __tablename__ = "athletes"

    id = Column(Integer, primary_key=True, index=True)

    age = Column(Integer, nullable=True)
    gender = Column(String, nullable=True)
    height_cm = Column(Float, nullable=True)
    weight_kg = Column(Float, nullable=True)

    training_records = relationship(
        "TrainingRecord",
        back_populates="athlete"
    )

    assessments = relationship(
        "Assessment",
        back_populates="athlete"
    )


class TrainingRecord(Base):
    __tablename__ = "training_records"

    id = Column(Integer, primary_key=True, index=True)

    athlete_id = Column(
        Integer,
        ForeignKey("athletes.id"),
        nullable=False
    )

    training_hours = Column(Float, nullable=True)
    training_intensity = Column(Float, nullable=True)
    sleep_hours = Column(Float, nullable=True)
    fatigue_level = Column(Float, nullable=True)
    recovery_index = Column(Float, nullable=True)
    performance_score = Column(Float, nullable=True)

    athlete = relationship(
        "Athlete",
        back_populates="training_records"
    )


class Assessment(Base):
    __tablename__ = "assessments"

    id = Column(Integer, primary_key=True, index=True)

    athlete_id = Column(
        Integer,
        ForeignKey("athletes.id"),
        nullable=False
    )

    predicted_injury = Column(String, nullable=True)
    risk_level = Column(String, nullable=True)
    confidence = Column(Float, nullable=True)

    athlete = relationship(
        "Athlete",
        back_populates="assessments"
    )