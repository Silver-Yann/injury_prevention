from pathlib import Path
import pandas as pd


DATA_DIR = Path("datasets")


def load_training_recovery():
    df = pd.read_csv(
        DATA_DIR / "Athlete_Training_Recovery_Tracker_Dataset.csv"
    )

    result = pd.DataFrame(index=df.index)

    result["source_dataset"] = "athlete_training_recovery"

    result["athlete_id"] = df["Athlete_ID"]

    result["age"] = pd.NA
    result["gender"] = pd.NA
    result["height_cm"] = pd.NA
    result["weight_kg"] = pd.NA

    result["sport_type"] = df["Sport_Type"]
    result["position"] = pd.NA

    result["training_hours"] = df["Training_Hours"]
    result["training_intensity"] = df["Training_Intensity"]
    result["sleep_hours"] = df["Sleep_Hours"]
    result["nutrition_score"] = df["Nutrition_Score"]
    result["fatigue_level"] = df["Fatigue_Level"]
    result["recovery_index"] = df["Recovery_Index"]
    result["performance_score"] = df["Performance_Score"]

    result["team_contribution_score"] = pd.NA
    result["load_balance_score"] = pd.NA
    result["recovery_days_per_week"] = pd.NA
    result["match_count_per_week"] = pd.NA
    result["rest_between_events_days"] = pd.NA
    result["training_hours_per_week"] = pd.NA

    result["acl_risk_score"] = pd.NA
    result["injury_indicator"] = pd.NA

    # Correct target mapping
    result["injury_risk"] = df["Injury_Risk"]
    result["injury_type"] = pd.NA
    result["injury_risk_factor"] = pd.NA

    result["date"] = df["Date"]

    result["fitness_level"] = pd.NA
    result["movement_type"] = pd.NA
    result["time_sec"] = pd.NA
    result["knee_angle_deg"] = pd.NA
    result["hip_angle_deg"] = pd.NA
    result["ankle_angle_deg"] = pd.NA
    result["velocity_m_s"] = pd.NA
    result["acceleration_m_s2"] = pd.NA
    result["knee_load_n"] = pd.NA
    result["hip_load_n"] = pd.NA
    result["ankle_load_n"] = pd.NA
    result["quad_emg_mv"] = pd.NA
    result["hamstring_emg_mv"] = pd.NA
    result["calf_emg_mv"] = pd.NA
    result["irregularities_detected"] = pd.NA
    result["movement_symmetry"] = pd.NA

    return result


def load_biomechanical():
    df = pd.read_csv(
        DATA_DIR / "biomechanical_injury_prevention_dataset.csv"
    )

    result = pd.DataFrame(index=df.index)

    result["source_dataset"] = "biomechanical_injury_prevention"

    result["athlete_id"] = df["Subject ID"]

    result["age"] = df["Age"]
    result["gender"] = df["Gender"]
    result["height_cm"] = df["Height (cm)"]
    result["weight_kg"] = df["Weight (kg)"]

    result["sport_type"] = pd.NA
    result["position"] = pd.NA

    result["training_hours"] = pd.NA
    result["training_intensity"] = pd.NA
    result["sleep_hours"] = pd.NA
    result["nutrition_score"] = pd.NA
    result["fatigue_level"] = pd.NA
    result["recovery_index"] = pd.NA
    result["performance_score"] = pd.NA

    result["team_contribution_score"] = pd.NA
    result["load_balance_score"] = pd.NA
    result["recovery_days_per_week"] = pd.NA
    result["match_count_per_week"] = pd.NA
    result["rest_between_events_days"] = pd.NA
    result["training_hours_per_week"] = pd.NA

    result["acl_risk_score"] = pd.NA
    result["injury_indicator"] = pd.NA

    # Correct target mapping
    result["injury_risk"] = pd.NA
    result["injury_type"] = df["Injury Type"]
    result["injury_risk_factor"] = df["Injury Risk Factor"]

    result["date"] = pd.NA

    result["fitness_level"] = df["Fitness Level"]
    result["movement_type"] = df["Movement Type"]
    result["time_sec"] = df["Time (sec)"]
    result["knee_angle_deg"] = df["Knee Angle (deg)"]
    result["hip_angle_deg"] = df["Hip Angle (deg)"]
    result["ankle_angle_deg"] = df["Ankle Angle (deg)"]
    result["velocity_m_s"] = df["Velocity (m/s)"]
    result["acceleration_m_s2"] = df["Acceleration (m/s²)"]
    result["knee_load_n"] = df["Knee Load (N)"]
    result["hip_load_n"] = df["Hip Load (N)"]
    result["ankle_load_n"] = df["Ankle Load (N)"]
    result["quad_emg_mv"] = df["Quad EMG (mV)"]
    result["hamstring_emg_mv"] = df["Hamstring EMG (mV)"]
    result["calf_emg_mv"] = df["Calf EMG (mV)"]
    result["irregularities_detected"] = df["Irregularities Detected"]
    result["movement_symmetry"] = df["Movement Symmetry"]

    return result


def load_collegiate():
    df = pd.read_csv(
        DATA_DIR / "collegiate_athlete_injury_dataset.csv"
    )

    result = pd.DataFrame(index=df.index)

    result["source_dataset"] = "collegiate_athlete_injury"

    result["athlete_id"] = df["Athlete_ID"]

    result["age"] = df["Age"]
    result["gender"] = df["Gender"]
    result["height_cm"] = df["Height_cm"]
    result["weight_kg"] = df["Weight_kg"]

    result["sport_type"] = pd.NA
    result["position"] = df["Position"]

    result["training_hours"] = pd.NA
    result["training_intensity"] = df["Training_Intensity"]
    result["sleep_hours"] = pd.NA
    result["nutrition_score"] = pd.NA
    result["fatigue_level"] = df["Fatigue_Score"]
    result["recovery_index"] = pd.NA
    result["performance_score"] = df["Performance_Score"]

    result["team_contribution_score"] = df["Team_Contribution_Score"]
    result["load_balance_score"] = df["Load_Balance_Score"]
    result["recovery_days_per_week"] = df["Recovery_Days_Per_Week"]
    result["match_count_per_week"] = df["Match_Count_Per_Week"]
    result["rest_between_events_days"] = df["Rest_Between_Events_Days"]
    result["training_hours_per_week"] = df["Training_Hours_Per_Week"]

    result["acl_risk_score"] = df["ACL_Risk_Score"]
    result["injury_indicator"] = df["Injury_Indicator"]

    result["injury_risk"] = pd.NA
    result["injury_type"] = pd.NA
    result["injury_risk_factor"] = pd.NA

    result["date"] = pd.NA

    result["fitness_level"] = pd.NA
    result["movement_type"] = pd.NA
    result["time_sec"] = pd.NA
    result["knee_angle_deg"] = pd.NA
    result["hip_angle_deg"] = pd.NA
    result["ankle_angle_deg"] = pd.NA
    result["velocity_m_s"] = pd.NA
    result["acceleration_m_s2"] = pd.NA
    result["knee_load_n"] = pd.NA
    result["hip_load_n"] = pd.NA
    result["ankle_load_n"] = pd.NA
    result["quad_emg_mv"] = pd.NA
    result["hamstring_emg_mv"] = pd.NA
    result["calf_emg_mv"] = pd.NA
    result["irregularities_detected"] = pd.NA
    result["movement_symmetry"] = pd.NA

    return result


def main():
    training = load_training_recovery()
    biomechanics = load_biomechanical()
    collegiate = load_collegiate()

    golden = pd.concat(
        [training, biomechanics, collegiate],
        ignore_index=True
    )

    output_file = DATA_DIR / "golden_dataset.csv"
    golden.to_csv(output_file, index=False)

    print(f"Golden dataset created: {output_file}")
    print(f"Rows: {len(golden)}")
    print(f"Columns: {len(golden.columns)}")


if __name__ == "__main__":
    main()