from pathlib import Path
import pandas as pd


DATA_DIR = Path("datasets")


def print_header(title):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def analyse_source_datasets():
    print_header("SOURCE DATASET CHECK")

    csv_files = [
        DATA_DIR / "Athlete_Training_Recovery_Tracker_Dataset.csv",
        DATA_DIR / "biomechanical_injury_prevention_dataset.csv",
        DATA_DIR / "collegiate_athlete_injury_dataset.csv",
    ]

    for file_path in csv_files:
        df = pd.read_csv(file_path)

        print(f"\nDATASET: {file_path.name}")
        print(f"Rows: {len(df)}")
        print(f"Columns: {len(df.columns)}")
        print(f"Missing values: {df.isnull().sum().sum()}")
        print(f"Duplicate rows: {df.duplicated().sum()}")


def analyse_golden_dataset():
    print_header("GOLDEN DATASET CHECK")

    file_path = DATA_DIR / "golden_dataset.csv"

    if not file_path.exists():
        print("ERROR: golden_dataset.csv was not found.")
        return False

    df = pd.read_csv(file_path)

    print(f"Rows: {len(df)}")
    print(f"Columns: {len(df.columns)}")
    print(f"Duplicate rows: {df.duplicated().sum()}")

    print("\nRows per source:")
    print(df["source_dataset"].value_counts())

    return df


def check_required_columns(df):
    print_header("REQUIRED COLUMN CHECK")

    required_columns = [
        "source_dataset",
        "athlete_id",
        "age",
        "gender",
        "height_cm",
        "weight_kg",
        "sport_type",
        "position",
        "training_hours",
        "training_intensity",
        "sleep_hours",
        "nutrition_score",
        "fatigue_level",
        "recovery_index",
        "performance_score",
        "team_contribution_score",
        "load_balance_score",
        "recovery_days_per_week",
        "match_count_per_week",
        "rest_between_events_days",
        "training_hours_per_week",
        "acl_risk_score",
        "injury_indicator",
        "injury_risk",
        "injury_type",
        "injury_risk_factor",
        "date",
        "fitness_level",
        "movement_type",
        "time_sec",
        "knee_angle_deg",
        "hip_angle_deg",
        "ankle_angle_deg",
        "velocity_m_s",
        "acceleration_m_s2",
        "knee_load_n",
        "hip_load_n",
        "ankle_load_n",
        "quad_emg_mv",
        "hamstring_emg_mv",
        "calf_emg_mv",
        "irregularities_detected",
        "movement_symmetry",
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing_columns:
        print("FAIL - missing columns:")
        for column in missing_columns:
            print(f"- {column}")
        return False

    print("PASS - all required columns are present.")
    return True


def check_source_counts(df):
    print_header("SOURCE ROW COUNT CHECK")

    expected_counts = {
        "athlete_training_recovery": 1000,
        "biomechanical_injury_prevention": 1000,
        "collegiate_athlete_injury": 200,
    }

    passed = True

    for source, expected in expected_counts.items():
        actual = len(df[df["source_dataset"] == source])

        status = "PASS" if actual == expected else "FAIL"

        print(
            f"{status} - {source}: "
            f"expected {expected}, found {actual}"
        )

        if actual != expected:
            passed = False

    return passed


def check_target_mapping(df):
    print_header("TARGET MAPPING CHECK")

    passed = True

    training = df[
        df["source_dataset"] == "athlete_training_recovery"
    ]

    biomechanical = df[
        df["source_dataset"] == "biomechanical_injury_prevention"
    ]

    collegiate = df[
        df["source_dataset"] == "collegiate_athlete_injury"
    ]

    # Training/recovery
    checks = [
        (
            training["injury_risk"].notna().all(),
            "Training dataset: injury_risk is populated"
        ),
        (
            training["injury_type"].isna().all(),
            "Training dataset: injury_type is empty"
        ),
        (
            training["injury_risk_factor"].isna().all(),
            "Training dataset: injury_risk_factor is empty"
        ),

        # Biomechanical
        (
            biomechanical["injury_type"].notna().all(),
            "Biomechanical dataset: injury_type is populated"
        ),
        (
            biomechanical["injury_risk_factor"].notna().all(),
            "Biomechanical dataset: injury_risk_factor is populated"
        ),
        (
            biomechanical["injury_risk"].isna().all(),
            "Biomechanical dataset: injury_risk is empty"
        ),

        # Collegiate
        (
            collegiate["injury_indicator"].notna().all(),
            "Collegiate dataset: injury_indicator is populated"
        ),
        (
            collegiate["acl_risk_score"].notna().all(),
            "Collegiate dataset: acl_risk_score is populated"
        ),
        (
            collegiate["injury_type"].isna().all(),
            "Collegiate dataset: injury_type is empty"
        ),
        (
            collegiate["injury_risk"].isna().all(),
            "Collegiate dataset: injury_risk is empty"
        ),
        (
            collegiate["injury_risk_factor"].isna().all(),
            "Collegiate dataset: injury_risk_factor is empty"
        ),
    ]

    for condition, description in checks:
        if condition:
            print(f"PASS - {description}")
        else:
            print(f"FAIL - {description}")
            passed = False

    return passed


def check_target_values(df):
    print_header("TARGET VALUE CHECK")

    passed = True

    training = df[
        df["source_dataset"] == "athlete_training_recovery"
    ]

    biomechanical = df[
        df["source_dataset"] == "biomechanical_injury_prevention"
    ]

    collegiate = df[
        df["source_dataset"] == "collegiate_athlete_injury"
    ]

    expected_training_risks = {"Low", "Medium", "High"}

    actual_training_risks = set(
        training["injury_risk"].dropna().unique()
    )

    if actual_training_risks.issubset(expected_training_risks):
        print(
            "PASS - Training injury_risk contains only "
            "Low/Medium/High"
        )
    else:
        print(
            "FAIL - Unexpected training injury_risk values:",
            actual_training_risks
        )
        passed = False

    expected_biomechanical_risks = {"Low", "Medium", "High"}

    actual_biomechanical_risks = set(
        biomechanical["injury_risk_factor"]
        .dropna()
        .unique()
    )

    if actual_biomechanical_risks.issubset(
        expected_biomechanical_risks
    ):
        print(
            "PASS - Biomechanical injury_risk_factor "
            "contains only Low/Medium/High"
        )
    else:
        print(
            "FAIL - Unexpected biomechanical risk values:",
            actual_biomechanical_risks
        )
        passed = False

    expected_injury_types = {
        "No Injury",
        "Ankle Sprain",
        "Knee Injury",
    }

    actual_injury_types = set(
        biomechanical["injury_type"].dropna().unique()
    )

    if actual_injury_types.issubset(expected_injury_types):
        print(
            "PASS - Biomechanical injury_type contains "
            "expected categories"
        )
    else:
        print(
            "FAIL - Unexpected biomechanical injury types:",
            actual_injury_types
        )
        passed = False

    expected_indicator_values = {0, 1}

    actual_indicator_values = set(
        collegiate["injury_indicator"]
        .dropna()
        .astype(int)
        .unique()
    )

    if actual_indicator_values.issubset(expected_indicator_values):
        print(
            "PASS - Collegiate injury_indicator contains only 0/1"
        )
    else:
        print(
            "FAIL - Unexpected injury_indicator values:",
            actual_indicator_values
        )
        passed = False

    return passed


def check_important_feature_mapping(df):
    print_header("IMPORTANT FEATURE CHECK")

    passed = True

    biomechanical = df[
        df["source_dataset"] == "biomechanical_injury_prevention"
    ]

    columns = [
        "knee_angle_deg",
        "hip_angle_deg",
        "ankle_angle_deg",
        "velocity_m_s",
        "acceleration_m_s2",
        "knee_load_n",
        "hip_load_n",
        "ankle_load_n",
        "quad_emg_mv",
        "hamstring_emg_mv",
        "calf_emg_mv",
        "movement_symmetry",
    ]

    for column in columns:
        if biomechanical[column].notna().all():
            print(f"PASS - {column} is populated")
        else:
            print(f"FAIL - {column} has missing values")
            passed = False

    return passed


def main():
    analyse_source_datasets()

    df = analyse_golden_dataset()

    if isinstance(df, bool) and df is False:
        return

    results = []

    results.append(check_required_columns(df))
    results.append(check_source_counts(df))
    results.append(check_target_mapping(df))
    results.append(check_target_values(df))
    results.append(check_important_feature_mapping(df))

    print_header("FINAL RESULT")

    if all(results):
        print("PASS - Golden dataset looks correct.")
        print("T3-01 dataset mapping checks completed successfully.")
    else:
        print("FAIL - Golden dataset still has problems.")
        print("Check the failed tests above before closing T3-01.")


if __name__ == "__main__":
    main()